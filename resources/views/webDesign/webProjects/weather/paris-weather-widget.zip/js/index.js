var weather = $.getJSON('https://api.openweathermap.org/data/2.5/find?q=Paris&units=metric&appid=c02f87a1bfe000a9d384144576f3b269');
var iconUrl = "http://openweathermap.org/img/w/";
var zeroDegreeHeight = 71;

weather.done(function(data) {
  var currentTempParis = Math.round(data.list[0].main.temp).toFixed(0);
  $('.thermometer').append("<span>"+ currentTempParis +"</span>");
  var currentTempHeight = zeroDegreeHeight + (currentTempParis * 3);
  $(".thermometer--mercury").height(currentTempHeight);
  
  weatherIcon(data.list[0].weather[0].icon);
  
   var conditions = data.list[0].weather[0].description;
  $(".details").append("<p>"+ conditions +"</p>");
});

function weatherIcon(icon) {
  var timeOfDay = icon.substr(-1);
  var condition = icon.slice(0,2);
  if (timeOfDay === "d") {
    switch (condition) { 
      case '01': 
        icon = "wi-day-sunny";
        break;
      case '02': 
        icon = "wi-day-cloudy";
        break;
      case '03': 
        icon = "wi-day-cloudy-high";
        break;		
      case '04': 
        icon = "wi-cloudy";
        break;
       case '09': 
        icon = "wi-day-rain-mix";
        break;
      case '10': 
        icon = "wi-day-rain";
        break;
      case '11': 
        icon = "wi-day-thunderstorm";
        break;		
      case '13': 
        icon = "wi-day-snow";
        break;
       case '13': 
        icon = "wi-raindrops";
        break;
      default:
        icon = "wi-day-cloudy";
      }
  } else {
        switch (condition) { 
      case '01': 
        icon = "wi-night-clear";
        break;
      case '02': 
        icon = "wi-night-alt-cloudy";
        break;
      case '03': 
        icon = "wi-night-alt-cloudy-windy";
        break;		
      case '04': 
        icon = "wi-cloudy";
        break;
       case '09': 
        icon = "wi-night-alt-rain-mix";
        break;
      case '10': 
        icon = "wi-night-alt-showers";
        break;
      case '11': 
        icon = "wi-night-alt-storm-showers";
        break;		
      case '13': 
        icon = "wi-night-alt-snow-wind";
        break;
       case '13': 
        icon = "wi-night-fog";
        break;
      default:
        icon = "wi-night-alt-cloudy-high";
      }
  }
  $("i").addClass(icon);
}