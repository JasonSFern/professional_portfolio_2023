A Pen created at CodePen.io. You can find this one at https://codepen.io/tvweinstock/pen/pjOPvY.

 Paris weather widget using openweathermap.org/api. The thermometer image is pure css, using gradients for the graduation marks. The mercury level may not be the most accurate, but the gradient is French flag inspired so how could it be wrong? 🇫🇷  😘